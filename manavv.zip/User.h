// User.h — Authentication module (Manav)
// Abstract base class + two roles. Other modules ask the object what it may do
// (user.canEditBlacklist()) instead of writing if (role == "admin") everywhere:
// that is polymorphism.
#pragma once
#include <string>

class User {
public:
    explicit User(const std::string& name) : name(name) {}
    virtual ~User() {}                       // virtual: deleting through User* is safe

    virtual std::string role() const = 0;    // pure virtual = User is abstract
    virtual bool canEditBlacklist() const = 0;
    virtual bool canViewHistory() const = 0;
    virtual bool canManageUsers() const = 0;

    const std::string& getName() const { return name; }

protected:
    std::string name;
};

// Admin: full control of the system.
class Admin : public User {
public:
    explicit Admin(const std::string& name) : User(name) {}
    std::string role() const override { return "admin"; }
    bool canEditBlacklist() const override { return true; }
    bool canViewHistory() const override { return true; }
    bool canManageUsers() const override { return true; }
};

// Analyst: can look, cannot change anything.
class Analyst : public User {
public:
    explicit Analyst(const std::string& name) : User(name) {}
    std::string role() const override { return "analyst"; }
    bool canEditBlacklist() const override { return false; }
    bool canViewHistory() const override { return true; }
    bool canManageUsers() const override { return false; }
};
