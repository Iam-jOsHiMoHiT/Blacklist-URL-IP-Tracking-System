// Captcha.cpp — Authentication module (Manav)
#include "Captcha.h"

#include <cctype>
#include <chrono>

Captcha::Captcha() {
    std::random_device rd;
    unsigned t = static_cast<unsigned>(std::chrono::high_resolution_clock::now().time_since_epoch().count());
    rng.seed(rd() ^ t);
}

Captcha::Captcha(unsigned seed) : rng(seed) {}

CaptchaChallenge Captcha::next() {
    std::uniform_int_distribution<int> kind(0, 1);
    return kind(rng) == 0 ? mathChallenge() : codeChallenge();
}

CaptchaChallenge Captcha::mathChallenge() {
    std::uniform_int_distribution<int> num(2, 15);
    std::uniform_int_distribution<int> op(0, 2);
    int a = num(rng), b = num(rng);
    CaptchaChallenge c;
    switch (op(rng)) {
        case 0:
            c.question = "What is " + std::to_string(a) + " + " + std::to_string(b) + "?";
            c.answer = std::to_string(a + b);
            break;
        case 1:
            if (a < b) std::swap(a, b);    // keep the answer positive
            c.question = "What is " + std::to_string(a) + " - " + std::to_string(b) + "?";
            c.answer = std::to_string(a - b);
            break;
        default:
            a = a % 10 + 1;                // small numbers for multiplication
            b = b % 10 + 1;
            c.question = "What is " + std::to_string(a) + " x " + std::to_string(b) + "?";
            c.answer = std::to_string(a * b);
            break;
    }
    return c;
}

CaptchaChallenge Captcha::codeChallenge() {
    // No 0/O, 1/I/L: they look alike and confuse humans
    static const std::string letters = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
    std::uniform_int_distribution<int> pick(0, static_cast<int>(letters.size()) - 1);
    std::string code;
    for (int i = 0; i < 5; ++i) code += letters[pick(rng)];

    CaptchaChallenge c;
    c.question = "Type these characters: " + code;
    c.answer = code;
    return c;
}

bool Captcha::check(const CaptchaChallenge& challenge, const std::string& input) {
    std::string cleaned;
    for (char ch : input)
        if (!std::isspace(static_cast<unsigned char>(ch)))
            cleaned += static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    return !cleaned.empty() && cleaned == challenge.answer;
}
