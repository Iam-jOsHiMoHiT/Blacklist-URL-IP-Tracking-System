# Authentication module (Manav) - Phase 2

## Files
- src/auth/User.h                    abstract User + Admin / Analyst (polymorphism)
- src/auth/Sha256.h/.cpp             SHA-256, verified with official test vectors
- src/auth/PasswordHasher.h/.cpp     random salt + 10,000-round hashing; passwords never stored
- src/auth/Captcha.h/.cpp            "Are you human?" check (math or type-the-code)
- src/auth/AuthManager.h/.cpp        register, login, CAPTCHA rule, lockout
- src/data/...                       Anirudh's Storage (users are saved through it)
- tests/test_auth.cpp                36 tests
- demo/auth_demo.cpp                 interactive login demo

## Build and run (from this folder)
    g++ -std=c++17 -Wall -Iinclude tests/test_auth.cpp src/auth/AuthManager.cpp src/auth/PasswordHasher.cpp src/auth/Sha256.cpp src/auth/Captcha.cpp src/data/FileStorage.cpp -o test_auth
    g++ -std=c++17 -Wall -Iinclude demo/auth_demo.cpp src/auth/AuthManager.cpp src/auth/PasswordHasher.cpp src/auth/Sha256.cpp src/auth/Captcha.cpp src/data/FileStorage.cpp -o auth_demo

    test_auth.exe
    auth_demo.exe

Demo accounts (created on first run): admin / Admin@123, analyst / Analyst123
Reset demo data:  rmdir /s /q data\auth_store

## Rules
- 3 failed attempts -> locked 30 s; next round 60 s; doubles up to 1 hour. Saved, so restart doesn't reset it.
- After any failed attempt, a CAPTCHA is required. A failed CAPTCHA counts as a failed attempt.
- Unknown username and wrong password give the same message (attackers can't discover usernames).
- Passwords: 8+ characters, at least one letter and one digit, not equal to the username.
- Checking a URL needs no login; login is for Admin/Analyst features.

## Honest limitations (say these if asked)
- A console CAPTCHA is a concept demo; a bot could read it. Real web systems use image/behaviour CAPTCHAs.
- Real products use a vetted crypto library and slow hashes like bcrypt/Argon2.
- Password is visible while typing in the console (hiding it is platform-specific; Phase 3).
